package com.oops.assignment7;

public interface StringComparison {
	public void compareString();

}
