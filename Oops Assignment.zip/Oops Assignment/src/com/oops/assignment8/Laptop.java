package com.oops.assignment8;

import java.util.Date;

public class Laptop extends Electornics
{

	public Laptop(int id, String semiconductorType, Date dateOfManufacturing) {
		super(id, semiconductorType, dateOfManufacturing);
		// TODO Auto-generated constructor stub
	}

}
