package com.oops.assignment8;

import java.util.Date;

public class LCD extends Electornics
{

	public LCD(int id, String semiconductorType, Date dateOfManufacturing) {
		super(id, semiconductorType, dateOfManufacturing);
		// TODO Auto-generated constructor stub
	}

}
