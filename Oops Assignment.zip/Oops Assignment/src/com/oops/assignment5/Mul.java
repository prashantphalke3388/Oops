package com.oops.assignment5;

public abstract class Mul extends Sub{

	@Override
	void mul(int a, int b) {
		int c=a*b;
		System.out.println("Mul: "+c);
		
	}



}
