package com.oops.assignment5;

public abstract class sum extends CalcAbs{

	@Override
	void sum(int a, int b) {
		int c=a+b;
		System.out.println("Sum: "+c);
		
	}

	

}
