package com.oops.assignment2;

public interface Shape 
{
   void area();
  
}
